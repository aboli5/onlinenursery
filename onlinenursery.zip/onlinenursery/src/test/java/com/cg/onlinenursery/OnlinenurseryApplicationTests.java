package com.cg.onlinenursery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinenurseryApplicationTests {

	@Test
	void contextLoads() {
	}

}
