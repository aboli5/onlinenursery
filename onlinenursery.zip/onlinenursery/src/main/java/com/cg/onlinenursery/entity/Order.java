package com.cg.onlinenursery.entity;

public class Order {

}
